# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Merger notification review

- **Birleşme ve Devralma Sayılan Haller ve Kontrol Kavramı Hakkında Kılavuz**
  - Kimlik: rekabet-kontrol-kavrami-kilavuzu
  - Yayıncı: Rekabet Kurumu
  - URL: https://www.rekabet.gov.tr/Dosya/kilavuzlar/birlesme-ve-devralma-sayilan-haller-ve-kontrol-kavrami-hakkinda-kilavuz.pdf
  - Erişim tarihi: 2026-08-04
  - SHA-256: 0859bad82a22b768f154b1dfabc57c362800c72144f22f522eba2ef8cc3f6b1b
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Kılavuz bu depoda yeniden dağıtılmaz. Güncellik, kapsam, değişiklik ve yeniden kullanım koşulları yetkili bir insan tarafından kaynak URL'de doğrulanmalıdır.
  - Rol: Kontrol değişikliği olgularını envanterlemek için dış kaynak metadata'sı; şirket politikası veya hukuki karar değildir
- **Birleşme ve Devralma İşlemlerinde Ciro Hesaplanmasına İlişkin Kılavuz**
  - Kimlik: rekabet-ciro-kilavuzu-2026
  - Yayıncı: Rekabet Kurumu
  - URL: https://www.rekabet.gov.tr/Dosya/bd-ciro-kilavuzu-20260504120128549.pdf
  - Erişim tarihi: 2026-08-04
  - SHA-256: da76a6fa9ce9512acc694fcb33e437f3e226b0b0364e2925a6ef3978ed03b2ea
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Kılavuz bu depoda yeniden dağıtılmaz. Güncellik, kapsam, değişiklik ve yeniden kullanım koşulları yetkili bir insan tarafından kaynak URL'de doğrulanmalıdır.
  - Rol: Finans'ın precomputed sonucunun kapsam ve sürüm sorularını düzenlemek için dış kaynak metadata'sı; asistan hesaplama yapmaz

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
