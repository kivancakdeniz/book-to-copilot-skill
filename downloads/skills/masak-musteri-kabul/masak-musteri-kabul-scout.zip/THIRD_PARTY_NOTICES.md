# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## AML customer acceptance (MASAK)

- **Suç gelirlerinin aklanmasının ve terörün finansmanının önlenmesine dair tedbirler hakkında yönetmelik**
  - Kimlik: masak-tedbirler-yonetmeligi
  - Yayıncı: MASAK
  - URL: https://masak.hmb.gov.tr/suc-gelirlerinin-aklanmasinin-ve-terorun-finansmaninin-onlenmesine-dair-tedbirler-hakkinda-yonetmelik-3/
  - Erişim tarihi: 2026-08-04
  - SHA-256: 242cbc47fdd7359f0312fbe59308e1e68ca97b697b0b22b7e5ff62cef6d77f6c
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Resmi içerik pakete alınmaz; güncellik, kapsam ve yeniden kullanım koşulları resmi sayfadan insan tarafından doğrulanmalıdır. Yöntem kaynağıdır, şirket kararı veya SİB/STR sonucu değildir.

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
