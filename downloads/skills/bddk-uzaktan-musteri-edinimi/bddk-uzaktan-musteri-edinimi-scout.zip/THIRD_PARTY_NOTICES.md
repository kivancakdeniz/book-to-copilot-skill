# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Remote customer onboarding (BDDK)

- **Bankalarca Kullanılacak Uzaktan Kimlik Tespiti Yöntemlerine ve Elektronik Ortamda Sözleşme İlişkisinin Kurulmasına İlişkin Yönetmelik**
  - Kimlik: resmi-gazete-uzaktan-kimlik-2021
  - Yayıncı: Resmî Gazete
  - URL: https://www.resmigazete.gov.tr/eskiler/2021/04/20210401-7.htm
  - Erişim tarihi: 2026-08-04
  - SHA-256: 1a0b58decd14454d8cbf7e6cb3cf3902cedbac8b7bcaf9644004429915ce15bf
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Resmî metin bu depoda yeniden dağıtılmaz. Kullanımdan önce kaynak URL, güncellik, kapsam, değişiklik ve yeniden kullanım koşulları yetkili bir insan tarafından doğrulanmalıdır.
  - Rol: Kısa ve atıflı inceleme yöntemi için dış kaynak metadata'sı; şirket politikası, hukuki tavsiye veya teknik sertifika değildir

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
