# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Pharmaceutical promotion review: audience and release gate

- **Beşerî Tıbbi Ürünlerin Tanıtım Faaliyetleri Hakkında Yönetmelik**
  - Kimlik: titck-tanitim-yonetmeligi-sayfasi
  - Yayıncı: Türkiye İlaç ve Tıbbî Cihaz Kurumu (TİTCK)
  - URL: https://www.titck.gov.tr/mevzuat/beseri-tibbi-urunlerin-tanitim-faaliyetleri-hakkinda-yonetmelik-27122018172726
  - Erişim tarihi: 2026-08-04
  - SHA-256: 552ce8f77c365599105d387e5d9d312998f26df634131faad66201a35ad027d1
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Resmî dış kaynak bu depoda yeniden dağıtılmaz. Güncel metin, kapsam, değişiklik ve yeniden kullanım koşulları yetkili bir insan tarafından kaynak URL'den doğrulanmalıdır.
  - Rol: Kısa ve atıflı ilaç tanıtımı inceleme yöntemi için TİTCK dış kaynak metadatası; şirket politikası, hukuki veya tıbbi tavsiye değildir
- **Beşerî Tıbbi Ürünlerin Tanıtım Faaliyetleri Hakkında Yönetmelik - Resmî Gazete yayımı**
  - Kimlik: resmi-gazete-tanitim-yonetmeligi-2015
  - Yayıncı: T.C. Resmî Gazete
  - URL: https://www.resmigazete.gov.tr/eskiler/2015/07/20150703-2.htm
  - Erişim tarihi: 2026-08-04
  - SHA-256: c23a03d934063bec7abd0a678cf947d2044af82f63d404a59028aaa5421191cf
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Resmî dış kaynak bu depoda yeniden dağıtılmaz. Güncel metin, kapsam, değişiklik ve yeniden kullanım koşulları yetkili bir insan tarafından kaynak URL'den doğrulanmalıdır.
  - Rol: Kısa ve atıflı ilaç tanıtımı inceleme yöntemi için Resmî Gazete dış kaynak metadatası; şirket politikası, hukuki veya tıbbi tavsiye değildir

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
