# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Discount price claim review

- **Fiyat bilgisi içeren reklamlar ile indirimli satış reklamları ve ticari uygulamaları hakkında kılavuz**
  - Kimlik: ticaret-bakanligi-fiyat-reklamlari-kilavuzu-2024
  - Yayıncı: Ticaret Bakanlığı
  - URL: https://tuketici.ticaret.gov.tr/haberler/fiyat-bilgisi-iceren-reklamlar-ile-indirimli-satis-reklamlari-ve-ticari-uygulamalari-hakkinda-kilavuz-guncellendi
  - Erişim tarihi: 2026-08-04
  - SHA-256: b7068660822b5184cd7f100760105d8567e9f99ad6b3639da30082f2b0e05c14
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Resmi içerik pakete alınmaz; güncellik, kapsam ve yeniden kullanım koşulları resmi sayfadan insan tarafından doğrulanmalıdır. Yöntem kaynağıdır, şirket kararı değildir.

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
