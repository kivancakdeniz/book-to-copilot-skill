# Copilot Studio GitHub Copilot harness kurulumu

Bu dosya, `indirimli-fiyat-denetimi` için doğrudan yüklenebilir mevcut-skill ZIP paketidir. Copilot Studio'da GitHub Copilot harness preview ile oluşturulmuş ajanın Build > Skills alanında mevcut skill yükleme akışını kullanın. ZIP kökünde `SKILL.md` ve beş destek dosyası bulunur.

Resmî yönerge: https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/skills-add-existing

Skill insan yetkisini devralmaz. MCP sunucuları, araçlar, bağlantılar, kimlik ve izinler bu ZIP'ten ayrı yapılandırılmalı ve doğrulanmalıdır.
