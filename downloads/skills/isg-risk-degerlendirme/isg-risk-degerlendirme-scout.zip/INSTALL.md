# Scout kurulumu

Bu ZIP'i depo kökünde açın. Skill `.copilot/skills/isg-risk-degerlendirme/` altına yerleşir. Yüklemeden önce içeriği inceleyin. Bu paket araç veya MCP bağlantısı kurmaz; nihai kararlar ve bütün eylemler yetkili insanlarda kalır.
