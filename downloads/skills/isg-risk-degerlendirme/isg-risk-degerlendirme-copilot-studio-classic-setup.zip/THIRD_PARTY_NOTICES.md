# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## OHS risk assessment: from change to commissioning gate

- **İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği**
  - Kimlik: isg-risk-degerlendirmesi-yonetmeligi-2012
  - Yayıncı: T.C. Resmî Gazete
  - URL: https://www.resmigazete.gov.tr/eskiler/2012/12/20121229-13.htm
  - Erişim tarihi: 2026-08-04
  - SHA-256: a1ab5bfc1ea7c305393d7fa75f33d7a7debaf97fe3a6e46cc5d4dfb9276a31dc
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Resmî dış kaynak bu depoda yeniden dağıtılmaz. Güncel metin, kapsam, değişiklik ve yeniden kullanım koşulları yetkili bir insan tarafından kaynak URL'den doğrulanmalıdır.
  - Rol: Kısa ve atıflı İSG inceleme yöntemi için dış kaynak metadatası; şirket politikası, hukuki veya mühendislik tavsiyesi ya da sertifikasyon değildir

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
