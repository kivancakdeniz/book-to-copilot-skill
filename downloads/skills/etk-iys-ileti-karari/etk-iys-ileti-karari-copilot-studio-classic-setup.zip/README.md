# Copilot Studio classic kurulum malzemesi

Bu `etk-iys-ileti-karari` paketi doğrudan ajan veya solution içe aktarma paketi değildir. Classic ortamında bir maker tarafından uygulanacak yönerge, bilgi ve kaynak metadatası sağlar. This is not a direct agent or solution import package.

## Kurulum

1. `instructions.md` içeriğini ajanın talimat alanına insan incelemesiyle uyarlayın.
2. `knowledge/` altındaki beş Markdown dosyasını ayrı bilgi kaynakları olarak ekleyin ve erişimi test edin.
3. `source-manifest.json` ile resmî kaynak metadatasını ve sentetik kaynak sınırını doğrulayın.

Nihai karar ve bütün operasyonel eylemler yetkili insanlarda kalır. MCP sunucuları, araçlar, bağlantılar, kimlik, izin ve yayımlama ayarları bu paketten ayrı yapılandırılmalıdır.
