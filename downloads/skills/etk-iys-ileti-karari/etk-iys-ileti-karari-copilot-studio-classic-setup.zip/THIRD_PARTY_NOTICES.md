# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Commercial message decision (ETK/IYS)

- **6563 sayılı Elektronik Ticaretin Düzenlenmesi Hakkında Kanun**
  - Kimlik: ETK-6563
  - Yayıncı: Mevzuat Bilgi Sistemi
  - URL: https://www.mevzuat.gov.tr/mevzuatmetin/1.5.6563.pdf
  - Erişim tarihi: 2026-08-04
  - SHA-256: 694e91667476fad13303b41295fbd6936c3c23d879ba50a8717a5961da9eb539
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Yalnız kaynak metadatası ve kısa atıflı yöntem özeti yeniden kullanılır; uzun pasajlar kopyalanmaz, güncellik ve resmî metin insan Legal tarafından doğrulanır.
  - Yeniden kullanım dayanağı: Kamuya açık resmî mevzuat, ticari ileti karar yöntemini çıkarmak için başvuru kaynağıdır.
- **Ticari İletişim ve Ticari Elektronik İletiler Hakkında Yönetmelik**
  - Kimlik: ETK-TICARI-ILETISIM-YONETMELIGI
  - Yayıncı: Resmî Gazete
  - URL: https://www.resmigazete.gov.tr/eskiler/2015/07/20150715-4.htm
  - Erişim tarihi: 2026-08-04
  - SHA-256: 94ba383d2b7a5392d20677f6a5a5e6da23fc3b8942f323085e2b543edeae6292
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Yalnız kaynak metadatası ve kısa atıflı yöntem özeti yeniden kullanılır; uzun pasajlar kopyalanmaz, güncellik ve resmî metin insan Legal tarafından doğrulanır.
  - Yeniden kullanım dayanağı: Kamuya açık resmî yönetmelik, ileti ve kanıt kontrol yöntemini çıkarmak için başvuru kaynağıdır.

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
