# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## KVKK privacy notice review

- **6698 sayılı Kişisel Verilerin Korunması Kanunu**
  - Kimlik: KVKK-6698
  - Yayıncı: Mevzuat Bilgi Sistemi
  - URL: https://www.mevzuat.gov.tr/mevzuatmetin/1.5.6698.pdf
  - Erişim tarihi: 2026-08-04
  - SHA-256: 1ad27253b0068d4c3d991b92b68c6bc1104439430160f4350a3f04fbb211f2b5
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Yalnız kaynak metadatası ve kısa atıflı yöntem özeti yeniden kullanılır; uzun pasajlar kopyalanmaz, güncellik ve resmî metin insan Legal tarafından doğrulanır.
  - Yeniden kullanım dayanağı: Kamuya açık resmî mevzuat, karar yöntemini çıkarmak için başvuru kaynağıdır.
- **Aydınlatma Yükümlülüğünün Yerine Getirilmesinde Uyulacak Usul ve Esaslar Hakkında Tebliğ**
  - Kimlik: KVKK-AYDINLATMA-TEBLIGI
  - Yayıncı: Resmî Gazete
  - URL: https://www.resmigazete.gov.tr/eskiler/2018/03/20180310-5.htm
  - Erişim tarihi: 2026-08-04
  - SHA-256: f40c0e9df0eb9ccbc3476284b34dcaa718ac9157b32781dc1a83a36badf286d9
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Yalnız kaynak metadatası ve kısa atıflı yöntem özeti yeniden kullanılır; uzun pasajlar kopyalanmaz, güncellik ve resmî metin insan Legal tarafından doğrulanır.
  - Yeniden kullanım dayanağı: Kamuya açık resmî tebliğ, aydınlatma kontrol yöntemini çıkarmak için başvuru kaynağıdır.

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
