# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Marketing claims review

- **Advertising and Marketing on the Internet: Rules of the Road**
  - Kimlik: ftc-rules-road-pdf
  - Yayıncı: U.S. Federal Trade Commission
  - URL: https://www.ftc.gov/system/files/ftc_gov/pdf/bus28-rulesroad-2023_508.pdf
  - Erişim tarihi: 2026-08-04
  - SHA-256: d000f004d9c28b66dd81a590e6ecdacc5f9d08caf7b6af626407436abebe336a
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: U.S. federal government works are generally not copyrightable under 17 U.S.C. 105; third-party material and assets must be checked separately.
  - Yeniden kullanım dayanağı: United States federal government works are generally not subject to domestic copyright (17 U.S.C. 105).
  - Rol: Public advertising-method source; not Lumena policy or legal advice
- **.com Disclosures: How to Make Effective Disclosures in Digital Advertising**
  - Kimlik: ftc-dot-com-disclosures-2013
  - Yayıncı: U.S. Federal Trade Commission
  - URL: https://www.ftc.gov/system/files/documents/plain-language/bus41-dot-com-disclosures-information-about-online-advertising.pdf
  - Erişim tarihi: 2026-08-04
  - SHA-256: b189fd2c01b21309021c9cba5ae2d5cb8abb55a555bde412e11f124c420a142e
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: U.S. federal government works are generally not copyrightable under 17 U.S.C. 105; third-party material and assets must be checked separately.
  - Yeniden kullanım dayanağı: United States federal government works are generally not subject to domestic copyright (17 U.S.C. 105).
  - Rol: Public digital-disclosure method; not Lumena policy or legal advice
- **Guides Concerning the Use of Endorsements and Testimonials in Advertising (16 CFR Part 255)**
  - Kimlik: ftc-endorsement-guides-2023-07-26
  - Yayıncı: Electronic Code of Federal Regulations
  - URL: https://www.ecfr.gov/api/versioner/v1/full/2023-07-26/title-16.xml?part=255
  - Erişim tarihi: 2026-08-04
  - SHA-256: feb1c8cfee82158c16c4210ef320bc93ffb2f414aa2bdce6e6772a77064180ea
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: U.S. federal government works are generally not copyrightable under 17 U.S.C. 105; third-party material and assets must be checked separately.
  - Yeniden kullanım dayanağı: United States federal government works are generally not subject to domestic copyright (17 U.S.C. 105).
  - Rol: Date-pinned official FTC endorsement-guides source; not Lumena policy or legal advice

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
