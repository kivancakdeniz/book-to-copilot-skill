# GitHub Copilot for VS Code kurulumu

Bu ZIP'i depo kökünde açın. Skill `.github/skills/investment-committee/` altına yerleşir. Dosyaları inceleyin, depoyu güvenilir bir çalışma alanında açın ve Copilot Agent ile uygun bir istek üzerinden çağırın. Nihai kararlar ve bütün eylemler yetkili insanlarda kalır.
