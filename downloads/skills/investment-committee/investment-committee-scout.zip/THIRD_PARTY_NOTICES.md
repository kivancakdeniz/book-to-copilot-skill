# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Investment committee appraisal

- **The Green Book - UK government guidance on appraisal**
  - Kimlik: green-book-2026
  - Yayıncı: HM Treasury and Government Finance Function
  - URL: https://assets.publishing.service.gov.uk/media/698dbcd17da91680ad7f4308/The_Green_Book_2026.pdf
  - Erişim tarihi: 2026-08-04
  - SHA-256: 275602acb918e4d32e46c59e5d0596bebcfc5e2820ec86f489a8651c523ccc37
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Only source metadata and a short attributed method summary are reused; verify the current official text and any third-party material named in the source.
  - Yeniden kullanım dayanağı: Open Government Licence v3.0 permits reuse with the required attribution.
  - Rol: Public appraisal method; not Asteria policy

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
