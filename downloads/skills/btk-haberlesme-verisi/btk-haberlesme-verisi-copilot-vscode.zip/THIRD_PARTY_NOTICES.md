# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Telecom communication data review

- **Elektronik Haberleşme Sektöründe Kişisel Verilerin İşlenmesi ve Gizliliğin Korunmasına İlişkin Yönetmelik**
  - Kimlik: btk-haberlesme-verileri-yonetmeligi-2020
  - Yayıncı: Bilgi Teknolojileri ve İletişim Kurumu / T.C. Resmî Gazete
  - URL: https://www.resmigazete.gov.tr/eskiler/2020/12/20201204-13.htm
  - Erişim tarihi: 2026-08-04
  - SHA-256: 8fc09febf358035b94bbdd43a7e3c14b598634797d5248a602be55fbd7ad957b
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Resmi içerik pakete alınmaz; güncellik, kapsam ve yeniden kullanım koşulları resmi sayfadan insan tarafından doğrulanmalıdır. Kısa yöntem kaynağıdır, şirket kararı veya hukuki tavsiye değildir; tek başına tüm mahremiyet hukukunu çözmez.

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
