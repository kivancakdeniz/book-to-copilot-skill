# Third-party notices

Bu paket resmî kaynakların tam içeriğini içermez. Kayıtlar yalnız kaynak metadatası ve yeniden kullanım uyarılarıdır.

## Crypto payment gateway review

- **Ödemelerde Kripto Varlıkların Kullanılmamasına Dair Yönetmelik**
  - Kimlik: tcmb-kripto-odeme-yonetmeligi-2021
  - Yayıncı: Türkiye Cumhuriyet Merkez Bankası / T.C. Resmî Gazete
  - URL: https://www.resmigazete.gov.tr/eskiler/2021/04/20210416-4.htm
  - Erişim tarihi: 2026-08-04
  - SHA-256: d16a7f69a0254d0838e0c06999c4308030ad93f3b0e5bf6fde448f72861447e8
  - Dağıtım: metadata-only
  - Yeniden kullanım sınırı: Resmi içerik pakete alınmaz; güncellik, kapsam ve yeniden kullanım koşulları resmi sayfadan insan tarafından doğrulanmalıdır. Kısa yöntem kaynağıdır, şirket kararı veya hukuki tavsiye değildir.

## Disclaimer

This package supports training and governance design. It is not legal, medical, engineering, or regulatory advice. Final decisions and all system actions remain with authorized humans. — Bu paket eğitim ve yönetişim tasarımı içindir; hukuki, tıbbi, mühendislik veya mevzuata uygunluk görüşü değildir. Nihai kararlar ve bütün sistem eylemleri yetkili insanlarda kalır.
